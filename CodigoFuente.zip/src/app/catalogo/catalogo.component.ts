import { Component } from '@angular/core';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent {
  producto = [1,2,3,4,5,6,7,8,12,123,4,4,2,3,3,4,55,5,43,4,4,5,5]
  
  
}
